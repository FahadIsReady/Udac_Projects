

import Foundation
import UIKit

class SentMemesCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var memeImageView1: UIImageView!
    
}

